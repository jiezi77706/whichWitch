/**
 * 统一导出所有数据库服务
 */

export * from './user.service';
export * from './work.service';
export * from './collection.service';
export * from './authorization.service';
export * from './like.service';
